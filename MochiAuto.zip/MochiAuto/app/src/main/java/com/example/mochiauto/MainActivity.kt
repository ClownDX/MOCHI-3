package com.example.mochiauto

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.roundToInt

/** Draws the face with the same renderer the car uses. */
class FacePreview(context: Context) : View(context) {
    private val renderer = MochiFaceRenderer()
    private val area = Rect()
    private var last = System.nanoTime()

    @Volatile var cfg = MochiConfig()
    /** 0 idle, 1 accelerate, 2 brake, 3 left, 4 right, -1 live sensors */
    var scenario = 0
    var engine: MotionEngine? = null
    var bank: MediaBank? = null

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        last = now
        area.set(0, 0, width, height)

        var st = MochiState.IDLE
        var lat = 0f
        var lon = 0f
        when (scenario) {
            1 -> { st = MochiState.ACCELERATING; lon = 4f }
            2 -> { st = MochiState.BRAKING; lon = -5f }
            3 -> { st = MochiState.TURNING_LEFT; lat = -4f }
            4 -> { st = MochiState.TURNING_RIGHT; lat = 4f }
            -1 -> engine?.let { st = it.state; lat = it.lat; lon = it.lon }
        }
        val b = bank
        b?.onState(st.ordinal)
        if (b == null || !b.drawVideo(canvas, area, st.ordinal, cfg.bgColor)) {
            renderer.draw(canvas, area, st, lat, lon, dt, cfg)
        }
        postInvalidateOnAnimation()
    }
}

class MainActivity : Activity() {

    private var cfg = MochiConfig()
    private lateinit var preview: FacePreview
    private lateinit var engine: MotionEngine
    private lateinit var root: LinearLayout
    private lateinit var scrollView: ScrollView
    private lateinit var bank: MediaBank
    private var target: LinearLayout? = null
    private var previewChips: List<TextView> = emptyList()
    private val boxes = arrayOfNulls<LinearLayout>(EVENT_COUNT)
    private val eventNames = listOf("Idle", "Accelerating", "Hard braking", "Turning left", "Turning right")
    private val stateColors = intArrayOf(
        0xFFD7E84A.toInt(), 0xFFFF5A1F.toInt(), 0xFF22E5D0.toInt(),
        Color.WHITE, 0xFFFF80AB.toInt(), 0xFFB388FF.toInt()
    )

    private val eyeColors = intArrayOf(
        Color.WHITE, 0xFF00E5FF.toInt(), 0xFF76FF03.toInt(), 0xFFFFC107.toInt(), 0xFFFF80AB.toInt()
    )
    private val blushColors = intArrayOf(
        0xFFFF7896.toInt(), 0xFFFF5252.toInt(), 0xFFFF9800.toInt(), 0xFFCE93D8.toInt(), 0xFF80D8FF.toInt()
    )
    private val bgColors = intArrayOf(
        Color.BLACK, 0xFF0A1030.toInt(), 0xFF1A0A1F.toInt(), 0xFF06210F.toInt(), 0xFF2B0A0A.toInt()
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = MochiPrefs.load(this)
        engine = MotionEngine(applicationContext)
        engine.config = cfg
        bank = MediaBank(applicationContext)
        bank.configure(cfg.events)

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.BLACK) }
        scrollView = scroll
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        scroll.addView(root)
        setContentView(scroll)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (preview.scenario == -1) engine.start()
    }

    override fun onPause() {
        super.onPause()
        engine.stop()
        bank.stopSound()
    }

    override fun onDestroy() {
        super.onDestroy()
        bank.release()
    }

    private fun change(f: (MochiConfig) -> MochiConfig) {
        cfg = f(cfg)
        MochiPrefs.save(this, cfg)
        preview.cfg = cfg
        engine.config = cfg
        bank.configure(cfg.events)
    }

    // ---------- UI ----------

    private fun build() {
        add(text("Mochi Auto", 26f, Color.WHITE))
        add(text("Changes apply instantly, including on the car screen.", 13f, 0xFF999999.toInt()))

        preview = FacePreview(this).apply {
            cfg = this@MainActivity.cfg
            engine = this@MainActivity.engine
            bank = this@MainActivity.bank
        }
        add(preview, 14, dp(220))

        previewChips = chips("Preview", listOf("Idle", "Accel", "Brake", "Left", "Right", "Live"), 0) { i ->
            setScenario(i)
        }
        add(text("Live: move the phone, shake it along the screen's front/back axis for accelerate/brake.", 12f, 0xFF777777.toInt()))
        add(text("Motion sensor: ${engine.status}", 12f, if (engine.status == "none found") Color.RED else 0xFF77DD77.toInt()))

        section("Face")
        chips("Eyes", listOf("Round", "Pixel", "Tall", "Wide", "Pill"), cfg.eyeStyle) { i -> change { it.copy(eyeStyle = i) } }
        chips("Mouth", listOf("None", "Smile", "Cat"), cfg.mouthStyle) { i -> change { it.copy(mouthStyle = i) } }
        swatches("Eye color", eyeColors, cfg.eyeColor) { c -> change { it.copy(eyeColor = c) } }
        swatches("Blush color", blushColors, cfg.blushColor) { c -> change { it.copy(blushColor = c) } }
        swatches("Background", bgColors, cfg.bgColor) { c -> change { it.copy(bgColor = c) } }
        toggle("Show blush", cfg.showBlush) { b -> change { it.copy(showBlush = b) } }

        section("Vehicle type")
        val desc = text(Vehicle.values()[cfg.vehicle.coerceIn(0, 3)].desc, 12f, 0xFF999999.toInt())
        chips("Profile", Vehicle.values().map { it.label }, cfg.vehicle) { i ->
            desc.text = Vehicle.values()[i].desc
            change { it.copy(vehicle = i) }
        }
        add(desc, 4)

        section("Animation")
        slider("Animation speed", 0.5f, 2f, cfg.animSpeed) { v -> change { it.copy(animSpeed = v) } }
        slider("Lean / tilt", 0f, 2f, cfg.lean) { v -> change { it.copy(lean = v) } }
        slider("Idle bobbing", 0f, 2f, cfg.bob) { v -> change { it.copy(bob = v) } }
        slider("Blink rate", 0.5f, 2f, cfg.blinkRate) { v -> change { it.copy(blinkRate = v) } }
        slider("Sensitivity", 0.5f, 2f, cfg.sensitivity) { v -> change { it.copy(sensitivity = v) } }
        toggle("Shake when braking hard", cfg.shake) { b -> change { it.copy(shake = b) } }

        section("Phone mounting")
        toggle("Phone upright (portrait, screen facing you)", cfg.upright) { b -> change { it.copy(upright = b) } }
        toggle("Swap left / right", cfg.invertLat) { b -> change { it.copy(invertLat = b) } }
        toggle("Swap forward / back", cfg.invertLon) { b -> change { it.copy(invertLon = b) } }

        section("Dasai style")
        toggle("Per-state eye colors, blink between motions", cfg.toyStyle) { b -> change { it.copy(toyStyle = b) } }
        swatches("Accelerating color", stateColors, cfg.colAccel) { c -> change { it.copy(colAccel = c) } }
        swatches("Hard brake color", stateColors, cfg.colBrake) { c -> change { it.copy(colBrake = c) } }
        swatches("Turning color", stateColors, cfg.colTurn) { c -> change { it.copy(colTurn = c) } }

        section("Sounds and videos per motion")
        add(
            text(
                "Pick a sound or video for each motion and trim it. Sounds play when the motion starts. " +
                    "Videos replace the face while the motion lasts (up to 6 s, looping).",
                12f, 0xFF777777.toInt()
            )
        )
        for (i in 0 until EVENT_COUNT) {
            add(text(eventNames[i], 16f, Color.WHITE), 20)
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            boxes[i] = box
            add(box)
            fillEvent(i)
        }

        diagnostics()

        val reset = Button(this).apply {
            text = "Reset to defaults"
            setOnClickListener {
                MochiPrefs.save(this@MainActivity, MochiConfig())
                recreate()
            }
        }
        add(reset, 24)

        add(
            text(
                "Car setup: Android Auto settings > tap Version 10 times > Developer settings > " +
                    "Unknown sources. Reconnect, then look for Mochi Auto in the car's app grid.",
                12f, 0xFF777777.toInt()
            ), 16
        )
    }

    private fun setScenario(i: Int) {
        if (i == 5) { preview.scenario = -1; engine.start() } else { preview.scenario = i; engine.stop() }
    }

    private fun selectPreview(i: Int) {
        previewChips.forEachIndexed { j, v -> paintChip(v, j == i) }
        setScenario(i)
    }

    private fun updateEvent(i: Int, refill: Boolean = true, f: (EventMedia) -> EventMedia) {
        change { c -> c.copy(events = c.events.mapIndexed { j, ev -> if (j == i) f(ev) else ev }) }
        if (refill) fillEvent(i)
    }

    private fun durationMs(path: String): Int = try {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 0
        } finally {
            r.release()
        }
    } catch (e: Exception) {
        0
    }

    private fun fmtSec(ms: Int) = String.format("%.1f s", ms / 1000f)

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        setOnClickListener { onClick() }
    }

    private fun rowOf(vararg views: View) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        views.forEach { row.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        add(row, 4)
    }

    private fun trimBar(label: String, durMs: Int, valueMs: Int, onChange: (Int) -> Unit) {
        val tv = text("$label: ${fmtSec(valueMs)}", 13f, 0xFFAAAAAA.toInt())
        add(tv, 8)
        val steps = (durMs / 100).coerceAtLeast(1)
        val sb = SeekBar(this).apply {
            max = steps
            progress = (valueMs / 100).coerceIn(0, steps)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val ms = progress * 100
                tv.text = "$label: ${fmtSec(ms)}"
                onChange(ms)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        add(sb, 2)
    }

    private fun fillEvent(i: Int) {
        val box = boxes[i] ?: return
        box.removeAllViews()
        target = box
        val e = cfg.events[i]
        val grey = 0xFFAAAAAA.toInt()

        // ---- Sound ----
        add(text(if (e.soundPath.isBlank()) "Sound: none" else "Sound: " + File(e.soundPath).name.takeLast(28), 13f, grey), 6)
        rowOf(
            button("Pick sound") { pick(i, false) },
            button("Test") { bank.playSound(i) },
            button("Clear") { updateEvent(i) { it.copy(soundPath = "", soundStartMs = 0, soundEndMs = 0) } }
        )
        if (e.soundPath.isNotBlank()) {
            val dur = durationMs(e.soundPath)
            if (dur > 0) {
                trimBar("Sound start", dur, e.soundStartMs) { ms ->
                    updateEvent(i, false) { ev ->
                        ev.copy(soundStartMs = ms.coerceAtMost(maxOf(0, (if (ev.soundEndMs > 0) ev.soundEndMs else dur) - 200)))
                    }
                }
                trimBar("Sound end", dur, if (e.soundEndMs <= 0) dur else e.soundEndMs) { ms ->
                    updateEvent(i, false) { ev ->
                        ev.copy(soundEndMs = if (ms >= dur - 100) 0 else ms.coerceAtLeast(ev.soundStartMs + 200))
                    }
                }
            }
            slider("Volume", 0f, 1f, e.volume) { v -> updateEvent(i, false) { ev -> ev.copy(volume = v) } }
        }

        // ---- Video ----
        add(text(if (e.videoPath.isBlank()) "Video: none (face is shown)" else "Video: " + File(e.videoPath).name.takeLast(28), 13f, grey), 12)
        rowOf(
            button("Pick video") { pick(i, true) },
            button("Preview") { selectPreview(i); scrollView.smoothScrollTo(0, 0) },
            button("Clear") { updateEvent(i) { it.copy(videoPath = "", videoStartMs = 0, videoEndMs = 0) } }
        )
        if (e.videoPath.isNotBlank()) {
            val dur = durationMs(e.videoPath)
            if (dur > 0) {
                trimBar("Video start", dur, e.videoStartMs) { ms ->
                    updateEvent(i, false) { ev ->
                        ev.copy(videoStartMs = ms.coerceAtMost(maxOf(0, (if (ev.videoEndMs > 0) ev.videoEndMs else dur) - 200)))
                    }
                }
                trimBar("Video end", dur, if (e.videoEndMs <= 0) dur else e.videoEndMs) { ms ->
                    updateEvent(i, false) { ev ->
                        ev.copy(videoEndMs = if (ms >= dur - 100) 0 else ms.coerceAtLeast(ev.videoStartMs + 200))
                    }
                }
            }
            add(text("Plays up to 6 s from the start point and loops. Large clips take a few seconds to load.", 11f, 0xFF777777.toInt()), 4)
        }
        target = null
    }

    private fun pick(i: Int, video: Boolean) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = if (video) "video/*" else "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(
            Intent.createChooser(intent, if (video) "Pick a video" else "Pick a sound"),
            REQ_BASE + i * 2 + (if (video) 1 else 0)
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || requestCode < REQ_BASE) return
        val uri = data?.data ?: return
        val idx = (requestCode - REQ_BASE) / 2
        val video = (requestCode - REQ_BASE) % 2 == 1
        if (idx !in 0 until EVENT_COUNT) return

        // Copy into app storage so the car service can always read it
        Thread {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(contentResolver.getType(uri))
                ?: (if (video) "mp4" else "m4a")
            val dir = File(filesDir, "media").apply { mkdirs() }
            val dest = File(dir, "ev${idx}_${if (video) "video" else "sound"}_${System.currentTimeMillis()}.$ext")
            val ok = try {
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(dest).use { out -> input.copyTo(out) }
                }
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                if (!ok) {
                    Toast.makeText(this, "Couldn't read that file", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val old = cfg.events[idx].let { if (video) it.videoPath else it.soundPath }
                if (video) {
                    updateEvent(idx) { it.copy(videoPath = dest.path, videoStartMs = 0, videoEndMs = 0) }
                } else {
                    updateEvent(idx) { it.copy(soundPath = dest.path, soundStartMs = 0, soundEndMs = 0) }
                }
                if (old.isNotBlank()) File(old).delete()
            }
        }.start()
    }

    private fun diagnostics() {
        section("Diagnostics")
        val aa = try {
            packageManager.getPackageInfo("com.google.android.projection.gearhead", 0).versionName
        } catch (e: Exception) {
            null
        }
        val svc = try {
            packageManager.queryIntentServices(Intent("androidx.car.app.CarAppService").setPackage(packageName), 0).isNotEmpty()
        } catch (e: Exception) {
            false
        }
        val good = 0xFF77DD77.toInt()
        add(text("Car service registered: " + (if (svc) "yes" else "NO"), 13f, if (svc) good else Color.RED), 8)
        add(text("Android Auto app: " + (aa ?: "not found"), 13f, if (aa != null) good else Color.RED), 4)
        add(text("Motion sensor: " + engine.status, 13f, if (engine.status == "none found") Color.RED else good), 4)
        add(button("Open Android Auto app info") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:com.google.android.projection.gearhead")))
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't open Android Auto info", Toast.LENGTH_SHORT).show()
            }
        }, 8)
        add(
            text(
                "Not in Customize launcher? 1) Android Auto > Developer settings > Unknown sources ON. " +
                    "2) Android Auto app info > Force stop, then Storage > Clear cache. " +
                    "3) Connect to the car (or the Desktop Head Unit) once, then reopen Customize launcher. " +
                    "The list only refreshes after a connection.",
                12f, 0xFF777777.toInt()
            ), 8
        )
    }

    private fun add(v: View, topDp: Int = 0, heightPx: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
        (target ?: root).addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx).apply {
            topMargin = dp(topDp)
        })
    }

    private fun text(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
    }

    private fun section(title: String) {
        add(text(title, 18f, Color.WHITE), 26)
    }

    private fun paintChip(v: View, on: Boolean) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(if (on) 0xFF3D5AFE.toInt() else 0xFF222222.toInt())
        }
    }

    private fun chips(label: String, options: List<String>, selected: Int, onPick: (Int) -> Unit): List<TextView> {
        add(text(label, 13f, 0xFFAAAAAA.toInt()), 14)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        options.forEachIndexed { i, name ->
            val tv = TextView(this).apply {
                text = name
                textSize = 13f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
            }
            paintChip(tv, i == selected)
            tv.setOnClickListener {
                views.forEachIndexed { j, other -> paintChip(other, j == i) }
                onPick(i)
            }
            views.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            })
        }
        add(row, 6)
        return views
    }

    private fun swatches(label: String, colors: IntArray, selected: Int, onPick: (Int) -> Unit) {
        add(text(label, 13f, 0xFFAAAAAA.toInt()), 14)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<View>()
        fun paint(v: View, color: Int, on: Boolean) {
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(3), if (on) 0xFF3D5AFE.toInt() else 0xFF444444.toInt())
            }
        }
        colors.forEachIndexed { i, c ->
            val v = View(this)
            paint(v, c, c == selected)
            v.setOnClickListener {
                views.forEachIndexed { j, other -> paint(other, colors[j], j == i) }
                onPick(c)
            }
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) })
        }
        add(row, 6)
    }

    private fun slider(label: String, min: Float, max: Float, value: Float, onChange: (Float) -> Unit) {
        val tv = text("$label: ${String.format("%.1f", value)}", 13f, 0xFFAAAAAA.toInt())
        add(tv, 14)
        val sb = SeekBar(this).apply {
            this.max = 100
            progress = ((value - min) / (max - min) * 100f).roundToInt().coerceIn(0, 100)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = min + (max - min) * progress / 100f
                tv.text = "$label: ${String.format("%.1f", v)}"
                onChange(v)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        add(sb, 2)
    }

    private fun toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            isChecked = value
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
        add(sw, 14)
    }
}

private const val REQ_BASE = 4100
